let currentSlideIndex = 0;
const slides = document.querySelectorAll('.slide');

function showSlide(index) {
    slides.forEach((slide, i) => {
        slide.style.display = i === index ? 'block' : 'none';
    });
}

function changeSlide(step) {
    currentSlideIndex = (currentSlideIndex + step + slides.length) % slides.length;
    showSlide(currentSlideIndex);
}

// Auto-start the slideshow
function autoSlide() {
    changeSlide(1);
    setTimeout(autoSlide, 5000); // Change slide every 5 seconds
}

// Initialize the slideshow
showSlide(currentSlideIndex);
autoSlide();


